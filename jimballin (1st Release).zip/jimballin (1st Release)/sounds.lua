SMODS.Sound{
    key="music_avatarbeat",
    path="music_avatarbeat.ogg",
    pitch=0.7,
    volume=0.6,
}